
# THIS FILE IS GENERATED FROM PYLIBTIFF SETUP.PY
short_version = '0.4.2'
version = '0.4.2'
full_version = '0.4.2'
git_revision = '51d6f2a41db654254397df1de6f9193e7317bce5'
release = True
if not release:
    version = full_version
